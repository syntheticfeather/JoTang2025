#ifndef PRINT_UTILS_H
#define PRINT_UTILS_H

void print_number(int num);
void print_message(const char *msg);

#endif